# massive_nurulfaradapurba_siang
 Tubas Individu
